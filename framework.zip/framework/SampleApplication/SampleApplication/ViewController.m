//
//  ViewController.m
//  NikazaLocationServicesTestApplication
//
//  Created by Shamsudheen.TK on 25/04/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import "ViewController.h"
#import "LocationContextViewController.h"

#define LOG_MAX_BUFFER ((int) 50000)

#import <NikazaLocationServices/NikazaLocationServices.h>

@interface ViewController () <NikazaLocationServicesScannerManagerDelegate>

@property (nonatomic, strong) NikazaLocationServicesScannerManager *locationServicesScanner;

@property (nonatomic, weak) IBOutlet UITextView *txtLog;

@property (nonatomic, strong) NSMutableArray *locationContextCollection;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     _locationContextCollection = [[NSMutableArray alloc] init];
    
    if (!_locationServicesScanner) {
        [self startLocationServicesFramework];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}

- (void)startLocationServicesFramework {
    _locationServicesScanner = [[NikazaLocationServicesScannerManager alloc] initWithAPI_KEY:@""];
    _locationServicesScanner.delegate = self;
    
    /*
     _locationServicesScanner.powerSavingMode               = NO;
     _locationServicesScanner.eddystoneSearch               = YES;
     _locationServicesScanner.apiInvocation_RSSI_Difference = 20;
     locationServicesScanner.lostBeaconTimeout              = 20.0;
     
     NSDictionary *additionalInfo = [[NSDictionary alloc] initWithObjectsAndKeys:@"youremail@gmail.com",@"email",@"+956868493",@"mobile", nil];
     _locationServicesScanner.additionalDataCollectionInfo  = additionalInfo;
     */
    
    //NSArray *tags = [[NSArray alloc] initWithObjects:@"Airport", nil];
    [_locationServicesScanner startLocationServicesFilterByTags:nil];
}

- (void)stopLocationServicesFramework {
    [_locationServicesScanner stopLocationServices];
    _locationServicesScanner = nil;
}

#pragma mark --
#pragma Nikaza Callbacks


#pragma Beacons
// When a new beacon is found, a `didFind_beacon:` call gets triggered
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didFind_beacon:(id)beaconInfo {
    
    if ([beaconInfo isKindOfClass:[CLBeacon class]]) {
        
        NSLog(@"Saw iBeacon!: %@", beaconInfo);
        
        [self updateLog:[NSString stringWithFormat:@"\n\nSaw iBeacon!: %@", beaconInfo]];
        
    } else if ([beaconInfo isKindOfClass:[EddystoneBeaconInfo class]]) {
        
        NSLog(@"Saw Eddystone!: %@", beaconInfo);
        
        [self updateLog:[NSString stringWithFormat:@"\n\nSaw Eddystone!: %@", beaconInfo]];
    }
}

// If a beacon is broadcasting URLs, `didFind_beaconURL:` is triggered.
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didFind_beaconURL:(NSURL *)url {
    NSLog(@"Found a URL!: %@", [url absoluteString]);
    [self updateLog:[NSString stringWithFormat:@"\n\nFound a URL!: %@", [url absoluteString]]];
}

// When an existing beacon is updated (RSSI change), a `didUpdate_beacon:` call gets triggered
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didUpdate_beacon:(id)beaconInfo {
    
    if ([beaconInfo isKindOfClass:[CLBeacon class]]) {
        
        //NSLog(@"Update iBeacon!: %@", beaconInfo);
        
        //[self updateLog:[NSString stringWithFormat:@"\n\nUpdate iBeacon!: %@", beaconInfo]];
        
    } else if ([beaconInfo isKindOfClass:[EddystoneBeaconInfo class]]) {
        
        //NSLog(@"Update Eddystone!: %@", beaconInfo);
        
        //[self updateLog:[NSString stringWithFormat:@"\n\nUpdate Eddystone!: %@", beaconInfo]];
    }
}

// When an existing beacon is no longer seen (exited from beacon region), a ‘didLose_beacon:’ call gets triggered
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didLose_beacon:(id)beaconInfo {
    
    if ([beaconInfo isKindOfClass:[CLBeacon class]]) {
        
        NSLog(@"Lost iBeacon!: %@", beaconInfo);
        
        [self updateLog:[NSString stringWithFormat:@"\n\nLost iBeacon!: %@", beaconInfo]];
        
    } else if ([beaconInfo isKindOfClass:[EddystoneBeaconInfo class]]) {
        
        NSLog(@"Lost Eddystone!: %@", beaconInfo);
        
        [self updateLog:[NSString stringWithFormat:@"\n\nLost Eddystone!: %@", beaconInfo]];
    }
}

// Invoked when the user enters a monitored region.
- (void)locationScanner:(CLLocationManager *)manager didEnter_region:(CLRegion *)region {
    NSLog(@"Entered iBeacon Region!: %@", region);
    [self updateLog:[NSString stringWithFormat:@"\n\nEntered iBeacon Region!: %@", region]];
}

// Invoked when the user exits a monitored region.
- (void)locationScanner:(CLLocationManager *)manager didExit_region:(CLRegion *)region {
    NSLog(@"Exited iBeacon Region!: %@", region);
    [self updateLog:[NSString stringWithFormat:@"\n\nExited iBeacon Region!: %@", region]];
}

// When entered into a geofence, a ‘didEnter_geofence:’ call gets triggered
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didEnter_geofence:(CLCircularRegion *)geofenceRegion {
    NSLog(@"Entered into geofence!: %@", geofenceRegion);
    [self updateLog:[NSString stringWithFormat:@"\n\nEntered into geofence!: %@", geofenceRegion]];
}

// When exited from a geofence, a ‘didExit_geofence:’ call gets triggered
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didExit_geofence:(CLCircularRegion *)geofenceRegion {
    NSLog(@"Exited geofence!: %@", geofenceRegion);
    [self updateLog:[NSString stringWithFormat:@"\n\nExited geofence!: %@", geofenceRegion]];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self showLocalNotification:@"Exited geofence"];
    });
}

// If location metadata response is received from Nikaza server, `didGetLocationMetadata_nikaza:` call gets triggered.
// ‘locationInfo’ contains location metadata key-value pairs.
// The server call to retrieve location metadata will trigger only when the geofence or beacon or tag events occurs or when the `RSSI difference = API_INVOCATION_RSSI_DIFFERENCE`.
// `API_INVOCATION_RSSI_DIFFERENCE` is applicable ONLY in case of beacons and can be modified in the configuration file.
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didGetLocationMetadata_nikaza:(NSDictionary *)locationInfo Error:(NSError *)error {
    if (!error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self showLocalNotification:[NSString stringWithFormat:@"Here are the Location details:\n%@", locationInfo]];
        });
        NSLog(@"Here are the Location details: %@", locationInfo);
        [self updateLog:[NSString stringWithFormat:@"\n\nHere are the Location details: %@", locationInfo]];
        [_locationContextCollection addObject:locationInfo];
    }
    else {
        [self updateLog:[NSString stringWithFormat:@"\n\n\nError: %@", error.localizedDescription]];
    }
}

// When a framework status or error is available, a ‘didUpdateStatus_framework:’ call gets triggered.
// Implement this delegate to enable the debug log.
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didUpdateStatus_framework:(NSDictionary *)status Error:(NSError *)error {
    if (error) {
        NSLog(@"Error: %@",error.localizedDescription);
        [self updateLog:[NSString stringWithFormat:@"\n\nError: %@",error.localizedDescription]];
    } else {
        NSLog(@"Status: %@",[status objectForKey:NSLocalizedDescriptionKey]);
        [self updateLog:[NSString stringWithFormat:@"\n\nStatus: %@",[status objectForKey:NSLocalizedDescriptionKey]]];
    }
}

- (void)updateLog:(NSString *)newLog {
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([newLog isKindOfClass:[NSString class]]) {
            if (_txtLog.text.length > LOG_MAX_BUFFER) {
                [_txtLog setText: newLog];
            }
            else {
                [_txtLog setText: [newLog stringByAppendingString:_txtLog.text]];
            }
        }
    });
}

- (IBAction)seeLocationContext:(id)sender {
    LocationContextViewController *LocationContextVC = [self.storyboard  instantiateViewControllerWithIdentifier:@"LocationContextViewController"];
    LocationContextVC.locationContextCollection = _locationContextCollection;
    [self presentViewController:LocationContextVC animated:YES completion:nil];
}

- (void)showLocalNotification:(NSString *)message {
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    if (state != UIApplicationStateActive) {
        UILocalNotification* localNotification = [[UILocalNotification alloc] init];
        localNotification.fireDate = [NSDate date];
        localNotification.alertBody = message;
        localNotification.timeZone = [NSTimeZone defaultTimeZone];
        [localNotification setSoundName:UILocalNotificationDefaultSoundName];
        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    }
}

@end

//
//  ViewController.h
//  NikazaLocationServicesTestApplication
//
//  Created by Shamsudheen.TK on 25/04/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end


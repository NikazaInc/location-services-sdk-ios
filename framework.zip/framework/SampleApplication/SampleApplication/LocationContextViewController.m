//
//  LocationContextViewController.m
//  NikazaLocationServicesTestApplication
//
//  Created by Shamsudheen.TK on 19/12/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import "LocationContextViewController.h"

@interface LocationContextViewController ()

@property (nonatomic, weak) IBOutlet UITextView *txtContext;

@end

@implementation LocationContextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (NSDictionary *locationContext in _locationContextCollection) {
        [_txtContext setText:[NSString stringWithFormat:@"%@\n\n%@", locationContext, _txtContext.text]];
    }
    if (0 == _locationContextCollection.count) {
        [_txtContext setText:@"Location context is not available!"];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)back:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

//
//  LocationContextViewController.h
//  NikazaLocationServicesTestApplication
//
//  Created by Shamsudheen.TK on 19/12/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationContextViewController : UIViewController

@property (nonatomic, weak) NSMutableArray *locationContextCollection;

@end

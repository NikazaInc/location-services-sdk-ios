//
//  NikazaLocationServicesScannerManager.h
//  NikazaLocationServices
//
//  Created by Shamsudheen.TK on 04/10/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

typedef enum
{
    NetworkNotAvaibale = 1,
    NetworkAvaibale
} NetworkConnectionStatus;

@class NikazaLocationServicesScannerManager;

@protocol NikazaLocationServicesScannerManagerDelegate <NSObject>

@optional

#pragma mark - Both iBeacon and Eddystone

/**
 * When a new beacon is found, a `didFind_beacon:` call gets triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didFind_beacon:(id)beaconInfo;

/**
 * When an existing beacon is no longer seen (exited from beacon region), a ‘didLose_beacon:’ call gets triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didLose_beacon:(id)beaconInfo;

/**
 * When an existing beacon is updated (RSSI change), a `didUpdate_beacon:` call gets triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didUpdate_beacon:(id)beaconInfo;


#pragma mark - Eddystone only

/**
 * If a beacon is broadcasting URLs, `didFind_beaconURL:` is triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didFind_beaconURL:(NSURL *)url;


#pragma mark - iBeacon only

/**
 * Invoked when the user enters a monitored region.
 */
- (void)locationScanner:(CLLocationManager *)manager didEnter_region:(CLRegion *)region;

/**
 * Invoked when the user exists a monitored region.
 */
- (void)locationScanner:(CLLocationManager *)manager didExit_region:(CLRegion *)region;


#pragma mark - Geofence only

/**
 * When entered into a geofence, a ‘didEnter_geofence:’ call gets triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didEnter_geofence:(CLCircularRegion *)geofenceRegion;

/**
 * When exited from a geofence, a ‘didExit_geofence:’ call gets triggered.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didExit_geofence:(CLCircularRegion *)geofenceRegion;


#pragma mark - Location context

/**
 * If location metadata response is received from Nikaza server, `didGetLocationMetadata_nikaza:` call gets triggered.
 * ‘locationInfo’ contains location metadata key-value pairs.
 * The server call to retrieve location metadata will trigger only when the geofence or beacon or tag events occurs
 * -or when the `RSSI difference = API_INVOCATION_RSSI_DIFFERENCE`.
 * `API_INVOCATION_RSSI_DIFFERENCE` is applicable ONLY in case of beacons and can be modified in the configuration file.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didGetLocationMetadata_nikaza:(NSDictionary *)locationInfo Error:(NSError *)error;


#pragma mark - Debug log

/**
 * When a framework status or error is available, a ‘didUpdateStatus_framework:’ call gets triggered.
 * Acting as a debug log callback.
 */
- (void)locationScanner:(NikazaLocationServicesScannerManager *)scanner didUpdateStatus_framework:(NSDictionary *)status Error:(NSError *)error;

@end

@interface NikazaLocationServicesScannerManager : NSObject

@property(nonatomic, weak) id<NikazaLocationServicesScannerManagerDelegate> delegate;

#pragma mark - Public properties

/**
 * Change powerSavingMode = NO; to use the GPS polling. This is significantly high accurate.
 * Note that, using only the region monitoring without GPS polling is significantly less accurate.
 * Default is YES.
 */
@property (nonatomic, assign) BOOL powerSavingMode;

/**
 * Change eddystoneSearch = YES to activate Eddystones scanning.
 * Default is NO.
 */
@property (nonatomic, assign) BOOL eddystoneSearch;

/**
 * RSSI difference to invoke the API.
 * Default is 20.
 */
@property (nonatomic, assign) int apiInvocation_RSSI_Difference;

/**
 * Timeout in seconds to detect the didLoseBeacon.
 * Default is 20.0.
 */
@property (nonatomic, assign) double lostBeaconTimeout;

/**
 * Additional details to pass for data collection.
 * Default is nil.
 */
@property (nonatomic, strong) NSDictionary *additionalDataCollectionInfo;

#pragma mark - Public methods
/**
 * Initializes the framework with api key.
 */
- (id)initWithAPI_KEY:(NSString *)apiKey;

/**
 * Starts the location services framework.
 * @input - tags to filter the location context.
 */
- (void)startLocationServicesFilterByTags:(NSArray *)tags;

/**
 * Stops the location services framework.
 */
- (void)stopLocationServices;

/**
 * Stops the Beacon scanning.
 */
- (void)stopBeaconScanning;

@end

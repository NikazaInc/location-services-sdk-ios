//
//  NikazaLocationServices.h
//  NikazaLocationServices
//
//  Created by Shamsudheen.TK on 25/04/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//  In this header, you should import all the public headers of your framework using statements like #import <NikazaLocationServices/PublicHeader.h>

#import <UIKit/UIKit.h>
#import <NikazaLocationServices/NikazaLocationServices.h>
#import <NikazaLocationServices/NikazaLocationServicesScannerManager.h>
#import <NikazaLocationServices/EddystoneBeaconInfo.h>

//! Project version number for NikazaLocationServices.
FOUNDATION_EXPORT double NikazaLocationServicesVersionNumber;

//! Project version string for NikazaLocationServices.
FOUNDATION_EXPORT const unsigned char NikazaLocationServicesVersionString[];

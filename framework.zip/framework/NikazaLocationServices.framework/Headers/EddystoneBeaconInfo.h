//
//  EddystoneBeaconInfo.h
//  NikazaLocationServices
//
//  Created by Shamsudheen.TK on 25/09/17.
//  Copyright © 2017 Nikaza, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef NS_ENUM(NSUInteger, EddystoneBeaconType) {
    kBeaconTypeEddystone = 1,
    kBeaconTypeEddystoneEID = 2,
};

typedef NS_ENUM(NSUInteger, FrameType) {
    kEddystoneUnknownFrameType = 0,
    kEddystoneUIDFrameType,
    kEddystoneURLFrameType,
    kEddystoneEIDFrameType,
    kEddystoneTelemetryFrameType,
};

/**
 *=-----------------------------------------------------------------------------------------------=
 * EddystoneBeaconID
 *=-----------------------------------------------------------------------------------------------=
 */
@interface EddystoneBeaconID : NSObject <NSCopying>

/**
 * The type of the beacon. Currently only a couple of types are supported.
 */
@property(nonatomic, assign, readonly) EddystoneBeaconType beaconType;

/**
 * The raw beaconID data.
 */
@property(nonatomic, copy, readonly) NSData *beaconID;

@end


/**
 *=-----------------------------------------------------------------------------------------------=
 * EddystoneBeaconInfo
 *=-----------------------------------------------------------------------------------------------=
 */
@interface EddystoneBeaconInfo : NSObject

/**
 * The most recent RSSI we got for this sighting. Sometimes the OS cannot compute one reliably, so
 * this value can be null.
 */
@property(nonatomic, strong, readonly) NSNumber *RSSI;

/**
 * The beaconID for this Eddystone. All beacons have an ID.
 */
@property(nonatomic, strong, readonly) EddystoneBeaconID *beaconID;

/**
 * The telemetry that may or may not have been seen for this beacon. If it's set, the contents of
 * it aren't terribly relevant to us, in general. See the Eddystone spec for more information
 * if you're really interested in the exact details.
 */
@property(nonatomic, copy, readonly) NSData *telemetry;

/**
 * Transmission power reported by beacon. This is in dB.
 */
@property(nonatomic, strong, readonly) NSNumber *txPower;

/**
 * Found date and time.
 */
@property(nonatomic, strong) NSDate *foundDate;

/**
 * lat of the beacon.
 */
@property(nonatomic, strong) NSString *lat;

/**
 * longitude of the beacon.
 */
@property(nonatomic, strong) NSString *lon;

/**
 * The scanner has seen a frame for an Eddystone. We'll need to know what type of Eddystone frame
 * it is, as there are a few types.
 */
+ (FrameType)frameTypeForFrame:(NSData *)frameData;

/**
 * Given the service data for a frame we know to be a UID frame, an RSSI sighting,
 * and -- optionally -- telemetry data (if we've seen it), create a new EddystoneBeaconInfo object to
 * represent this Eddystone
 */
+ (instancetype)beaconInfoForUIDFrameData:(NSData *)UIDFrameData
                                telemetry:(NSData *)telemetry
                                     RSSI:(NSNumber *)initialRSSI;

/**
 * Given the service data for a frame we know to be a UID frame, an RSSI sighting,
 * and -- optionally -- telemetry data (if we've seen it), create a new EddystoneBeaconInfo object to
 * represent this Eddystone
 */
+ (instancetype)beaconInfoForEIDFrameData:(NSData *)EIDFrameData
                                telemetry:(NSData *)telemetry
                                     RSSI:(NSNumber *)initialRSSI;

/**
 * If we're given a URL frame, extract the URL from it.
 */
+ (NSURL *)parseURLFromFrameData:(NSData *)URLFrameData;

/**
 * Convenience method to save everybody from creating these things all the time.
 */
+ (CBUUID *)eddystoneServiceID;

+ (EddystoneBeaconInfo *)testBeaconFromBeaconIDString:(NSString *)beaconID;

@end
